import static org.junit.Assert.*;
import org.junit.Test;

public class JUnit999 {
	@Test
	public void simpleAdd(){
		int result= 1;
		int expected= 1;
		assertEquals(result, expected);
		
	}
}
