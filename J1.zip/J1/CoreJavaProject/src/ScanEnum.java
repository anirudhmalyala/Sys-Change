
import java.util.Scanner;
import java.util.regex.Pattern;

enum Gender{M,F,m,f;}
public class ScanEnum {
	static Gender gen;

public static void main(String[] args) {
// TODO Auto-generated method stub

	Scanner sc = new Scanner(System.in); 
	for (Gender printGender : Gender.values())
		System.out.println("The valid gender values are: "+printGender);
	System.out.println("\n\n\nCommand Line Inputs of Persons");
	System.out.println("First Name: ");
	String fname = sc.nextLine();     
	System.out.println("Last Name: ");
	String lname = sc.nextLine();      
	System.out.print ("Gender: ");
	Gender gen= Gender.valueOf(sc.next());
	
		
	System.out.println("Person Details:");
	System.out.println("---------------"); 
	System.out.println("First Name: "+fname);       
	System.out.println("Last Name: "+lname);
	System.out.println("Gender: " + gen);
	}
}


