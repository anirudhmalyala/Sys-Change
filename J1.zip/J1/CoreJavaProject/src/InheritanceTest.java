class Parent{
	public void m1(){
		System.out.println("Parent");
	}
}
class Child extends Parent
{
	public void m2(){
		System.out.println("Child");
	}
}
public class InheritanceTest {

	public static void main(String[] args) {
		
		Parent Pc=new Child();
		Parent P=new Parent();
		Child C=new Child();
		//Child Cp=new Parent();
		Pc.m1();
	//	Pc.m2();
		P.m1();
	//	P.m2();
		C.m1();
		C.m2();
	//	Cp.m1();
	//	Cp.m2();

	}

}
