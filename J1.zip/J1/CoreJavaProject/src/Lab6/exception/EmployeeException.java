package Lab6.exception;

public class EmployeeException extends Exception {
	
	public EmployeeException(){
		System.out.println("Sal is less than 3K");
	}

}
