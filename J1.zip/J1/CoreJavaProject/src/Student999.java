
// Java program to demonstrate working of 
// hasCode() and toString() 
public class Student999 
{ 
    static int last_roll = 100;  
    int roll_no; 
  
    // Constructor 
    Student999() 
    { 
        roll_no = last_roll; 
        last_roll++; 
    } 
  
   // @Override
    public int meth() 
    { 
        return roll_no; 
    } 
  
    // Driver code 
    public static void main(String args[]) 
    { 
        Student999 s = new Student999(); 
  
        // Below two statements are equivalent 
        System.out.println(s); 
        System.out.println(s.toString()); 
    } 
}