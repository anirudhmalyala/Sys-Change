package Lab5.bean;

public class Employee 
{

public static   int id;
public  static String name;
public static long salary;
public static String desig;
public  static String insuscheme;

public  Employee(int d, String n,long s, String desi)
{
id=d;
name=n;
salary=s;
desig=desi;
}

}
