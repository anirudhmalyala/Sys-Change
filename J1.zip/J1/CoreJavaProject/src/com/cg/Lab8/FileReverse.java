package com.cg.Lab8;

import java.io.*;
import java.lang.*;

public class FileReverse 
{
	public static void main(String[] args)
	{
		try
		{
			FileReader fread= new FileReader("D:\\abc.txt");
			FileWriter fnew=new FileWriter("D:\\btydicssd.txt");    //donot create this file the vprog will create on its own
			BufferedReader buff= new BufferedReader(fread); 
			String line;
			String a;				//reverse the line eg:abc gf
			String reverse= ""; 			// o/p: fg cba
			while((line= buff.readLine())!=null)
			{
				a= new String(line);
				for(int i=a.length()-1;i>=0;i--)
				{
					reverse=reverse+a.charAt(i);
				}	
			}
			fnew.write(reverse);
			System.out.println(reverse);
			fnew.close();
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
}