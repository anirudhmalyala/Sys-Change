package com.cg.Lab7;

import java.util.ArrayList;
import java.util.*;

public class SevenTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter length");
		int length=sc.nextInt();
		
		System.out.println("Enter String");
		ArrayList<String> str=new ArrayList<String>();

		for(int i=0;i<length;i++){
			str.add(sc.next());
		}
		System.out.println("Input String is: "+str);
		
	Collections.sort(str);                      //without foreach
	
	System.out.println("Sorted String is: "+str);
	
	System.out.println("\nUsing Foreach");
	for(String nayaa: str)                    //using foreach
		System.out.print(nayaa+",	");
	}
}

