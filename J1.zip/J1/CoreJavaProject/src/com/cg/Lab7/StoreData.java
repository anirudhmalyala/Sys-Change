package com.cg.Lab7;
import java.util.*;

public class StoreData {

public static void main(String[] args) {

// TODO Auto-generated method stub
	Scanner sc=new Scanner(System.in);
	String[] str=new String[4];
	
	System.out.println("Enter String");
	for(int i=0;i<str.length;i++)
	{
		str[i]=sc.next();
	}
	
	System.out.println("The String is\n");
	
	for(int i=0;i<str.length;i++)
	{
		System.out.println(str[i]);
	}
	System.out.println("Sorted String with length is\n");
	for(int i=0;i<str.length;i++)
	{
		for(int j=i+1;j<str.length;j++)
		{
			if(str[i].length()>str[j].length())
			{
				String s=str[i];
				str[i]=str[j];
				str[j]=s;
			}
		}
		System.out.println(str[i]);
	}
	
	System.out.println("\nSorted String is\n");
	
	Arrays.sort(str);
	for (int i=0; i<str.length; i++) {
		System.out.print(str[i]);
		    System.out.print( "\n");
		}
}
}