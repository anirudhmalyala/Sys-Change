package com.cg.Lab4;

class CurrentAccount extends Acc{
	
//	//double overdraftlimit=2000;
	double od=1000;
	int check =0;
	
	void getWithdraw(double o){
		
		if(od<900)
		{
		balance-=o;
		od=Math.abs(balance);
		display();
		System.out.println("OverDarft balance is:"+od);
		}
		else
		{
		System.out.println("In OD Level");
		}
		if(od<=1000)
		{
		if(balance-o<0)
		{
			balance-=o;
			display();
			check=1;		
			if(balance<-1000)
			{
				System.out.println("you have reached od limit so the withdrawl amt is added to your acc");
				balance=balance+o;	
				display();
				check=0;
			}
		}
		else
		{		
			balance-=o;
			display();
		}
		
		if(check==1)
		{
			od=Math.abs(balance);	
			display();
			check=0;
		}
		}	
	}	
}	
