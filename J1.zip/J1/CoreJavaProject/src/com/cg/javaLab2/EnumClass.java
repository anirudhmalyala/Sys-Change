package com.cg.javaLab2;
import java.util.*;


public class EnumClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner(System.in);
		for (Gender printGender : Gender.values())
			System.out.println(printGender);
		while(true)
			try
		{
				System.out.print ("Gender: ");
				System.out.println("Gender: " + Gender.valueOf(s.next()));
		}
		catch (IllegalArgumentException InvalidGender)
		{
			System.out.println("	Error: " + InvalidGender);
		}

			
		

	}

}
