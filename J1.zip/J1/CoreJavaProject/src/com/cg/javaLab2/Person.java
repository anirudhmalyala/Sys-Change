package com.cg.javaLab2;

enum Gender{
M,F,O;
}

public class Person {
	String firstname;
	String lastname;
	Gender gender;
	long phoneno;
	
	
	
	Person(){
		firstname= "She";
		lastname= "Mal";
		gender= Gender.F;
		phoneno= 8074368474L;
	}
	
	Person(String fname, String lname, Gender gen, long pno){
		firstname=fname;
		lastname=lname;
		gender=gen;
		phoneno=pno;
	}

	void display(){
		System.out.println("---------------\nFirst Name: "+firstname+"\nLast name: "+lastname+"\nGender: "+gender+"\nPhone Number: "+phoneno);
	}

}
