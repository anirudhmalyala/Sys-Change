package com.cg.javaLab2;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Person Details:");
		
		Person p1= new Person("Anii","Mal",Gender.M,7036071260L);
		Person p2=new Person();	
		
		p1.display();
		p2.display();
		
	}
}