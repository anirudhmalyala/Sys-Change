package com.cg.javaLab2;

import java.util.Scanner;
enum Gend{Male,Female;}
public class PersonMain2 {

public static void main(String[] args) {
// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in); 
for (Gend printGender : Gend.values())
System.out.println("The valid gender values are: "+printGender);

System.out.println("\n\n\nCommand Line Inputs of Persons");
System.out.println("First Name: ");
String fname = sc.nextLine();     

System.out.println("Last Name: ");
String lname = sc.nextLine(); 
Gend g = Gend.valueOf(sc.next());
int i=0;
while(i<=0){
try
{
//System.out.print ("Gender: ");
	if(g==Gend.Male || g==Gend.Female) {
System.out.println("Gender: " + g);
i++;}else {g = Gend.valueOf(sc.next());}
}
//System.out.println("Person Details:");
catch (IllegalArgumentException InvalidGender)
{
System.out.println(" Error: " + InvalidGender);
}      
finally{
System.out.println("Person Details:");
        System.out.println("---------------");
        System.out.println("First Name: "+fname); 
        System.out.println("Last Name: "+lname);
        System.out.println("Gender: " + g); /* Here i cannot resolve the input . output is fine but I need in an an order. */
}
}
}
}