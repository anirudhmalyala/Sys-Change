package com.cg.operators;

public class RelOps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10, b=5;
		System.out.println("a==b is "+(a==b));
		System.out.println("a!=b is "+(a!=b));
		System.out.println("a>b is "+(a>b));
		System.out.println("a<b is "+(a<b));
		System.out.println("a>=b is "+(a>=b));
		System.out.println("a<=b is "+(a<=b));

	}
}
