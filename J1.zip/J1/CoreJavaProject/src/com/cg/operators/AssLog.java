package com.cg.operators;

public class AssLog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10, b=5;
		String out = a==b? "yes":"no";
		System.out.println("Answer is "+out);

	}

}
