package com.cg.operators;

public class ArithOps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10, b=10;
		int sum= a+b;
		int sub= a-b;
		int mul= a*b;
		int mod= a%b;
		int div= a/b;
		System.out.println("Addition of "+a+" and "+b+" is "+sum);
		System.out.println("Subtraction of "+a+" and "+b+" is "+sub);
		System.out.println("Product of "+a+" and "+b+" is "+mul);
		System.out.println("divison of "+a+" and "+b+" is "+div);
		System.out.println("Mod Divison of "+a+" and "+b+" is "+mod);

	}

}
