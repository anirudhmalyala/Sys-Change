package com.cg.javaObj;

public class Person {
	String firstname;
	String lastname;
	char gender;
	long phoneno;
	
enum Gender{
		Male,
		Female,
		Others;
	}
	
	Person(){
		firstname= "She";
		lastname= "Mal";
		gender= 'F';
		phoneno= 8074368474L;
	};
	Person(String fname, String lname, char gen, long pno){
		firstname=fname;
		lastname=lname;
		gender=gen;
		phoneno=pno;
	}

	void display(){
		System.out.println("---------------\nFirst Name: "+firstname+"\nLast name: "+lastname+"\nGender: "+gender+"\nPhone Number: "+phoneno);
	}

}
