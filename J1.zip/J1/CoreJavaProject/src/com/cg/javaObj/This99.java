package com.cg.javaObj;

class This999{
	
	This999 getThis(){
	return this;
	}
		void msg(){
			System.out.println("Hey!Anii Mal");
		}
		}

public class This99 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//new This999().getThis().msg();
		new This999().getThis();

	}

}
