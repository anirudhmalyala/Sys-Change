package com.cg.javaObj;

class Student99{
int id=1;
String name="a";//n var

Student99(int i,String n)//{}
{id=i; name=n;}

//Student99(Student99 s){id=s.id; name=s.name;}
Student99(){}

void display(){System.out.println(id+name);}

public static void main(String args[]){
Student99 s1=new Student99(1,"a");
Student99 s2=new Student99();
Student99 s3=new Student99();
s1.display();
s2.display();
s3.display();
}
}
