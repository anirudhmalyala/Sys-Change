package com;

import java.util.*; 
import java.util.regex.*;

public class Ass {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter email");
		String email=sc.nextLine();
		System.out.println("enter pattern");
		String pattern=sc.nextLine();
		boolean bool=Pattern.matches(pattern, email);
		if(bool==true){
			System.out.println("Valid Email!");
		}
		else
			System.out.println("Invalid Email");
				
	}
}
