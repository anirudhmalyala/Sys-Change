 
class A2 {void m1(){
    System.out.println(" PArent");
}
}

public class A1 extends  A2{
    void m1(){
    	super.m1();
        System.out.println(" CHild"
        		+ ""
        		+ ".");
    }
    public static void main(String[] args){
    A2 b1=new A2();
  
    //A2 b2=(A2)A1;
    A1 b2=new A1();
    b1.m1();
    b2.m1();
}
    
}