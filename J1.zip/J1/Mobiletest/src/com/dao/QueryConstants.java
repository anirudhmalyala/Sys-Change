package com.dao;

public class QueryConstants {

	public static final String insertQuery = "insert into customer values(seq_cid.nextval,?,?,?)";
	public static final String checkIdQuery = "select quantity from mobile_test where mobileid=?";
	public static final String getId = "select max(id) from customer";
	public static final String updateQuery = "update mobile_test set quantity=quantity-? where mobileid=?";
}
