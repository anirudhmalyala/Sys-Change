package com.capgemini.tcc.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.tcc.exceptions.TakeCareClinicException;

public class JdbcUtility {
	private static Connection connection = null;

	public static Connection getConnection() throws TakeCareClinicException {

		Properties properties = new Properties();

		File file = new File("resources/jdbc.properties");
		FileInputStream inputStream = null;
		try {
			inputStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			throw new TakeCareClinicException(
					"The file doesnot exists in the database.");
		}

		try {
			properties.load(inputStream);

			String driver = properties.getProperty("driver");
			String url = properties.getProperty("url");
			String userName = properties.getProperty("username");
			String password = properties.getProperty("password");

			try {
				Class.forName(driver);
				connection = DriverManager.getConnection(url, userName,
						password);
			} catch (ClassNotFoundException e) {
				throw new TakeCareClinicException(
						"Class is not loaded. Try again!!");

			} catch (SQLException e) {
				throw new TakeCareClinicException(
						"The connection is not established properly. Please try again!!");
			}

		} catch (IOException e) {
			throw new TakeCareClinicException(
					"There's no date present in the file to read");
		}
		return connection;

	}
}
