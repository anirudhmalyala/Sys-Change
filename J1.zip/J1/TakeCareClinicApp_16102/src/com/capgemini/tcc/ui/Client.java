package com.capgemini.tcc.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareClinicException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {
	static Logger logger = Logger.getLogger(Client.class);

	public static void main(String[] args) throws TakeCareClinicException {

		PropertyConfigurator.configure("resources/log4j.properties");
		
		logger.info("The log4j file of this project is loaded successfully.");

		Scanner scanner = new Scanner(System.in);
		IPatientService patientService = new PatientService();

		while (true) {
			System.out.println("1.		Add Patient Information");
			System.out.println("2.		Search patient by Id");
			System.out.println("3.		Exit");

			System.out.println("Select your choice");
			int choice = 0;
			try {
				choice = scanner.nextInt();
			} catch (InputMismatchException e) {
				// i.e., Given input is not a valid integer
				logger.error("Please enter integer values only.");
				System.err.println("Please enter only integer values.");
				System.exit(0);
			}

			switch (choice) {
			case 1:
				/**
				 * When user selects first case i.e., adding patient details
				 */
				logger.info("You've opted insertion operation.");

				scanner.nextLine();
				System.out.println("Enter the name of the Patient: ");
				String patientName = scanner.nextLine();
				System.out.println("Enter Patient Age:");
				int age = 0;
				try {
					age = scanner.nextInt();
				} catch (InputMismatchException e) {
					logger.error("Please enter integer values only.");
					System.err.println("Age should be digits only");
					System.exit(0);
				}

				System.out.println("Enter Patient phone number: ");
				long phoneNumber = 0;
				try {
					phoneNumber = scanner.nextLong();
				} catch (InputMismatchException e) {
					logger.error("Please enter integer values only.");
					System.err
							.println("Phone number should contain digits only");
					System.exit(0);
				}

				scanner.nextLine();
				System.out.println("Enter Description: ");
				String description = scanner.nextLine();

				PatientBean patient = new PatientBean();
				patient.setPatientName(patientName);
				patient.setAge(age);
				patient.setPhoneNumber(phoneNumber);
				patient.setDescription(description);

				try {
					boolean result = patientService.validateDetails(patient);

					if (result) {
						int patientId = patientService
								.addPatientDetails(patient);
						System.out
								.println("Patient Information stored successfully for "
										+ patientId);
					}
				} catch (TakeCareClinicException e) {
					logger.error("Error while storing the details.");
					System.err.println(e.getMessage());
				}
				break;

			case 2:
				/**
				 * When user selects second case i.e., searching patient by his
				 * patient_id
				 * 
				 * author @capgemini
				 */
				logger.info("You've selected the search details operation");

				System.out.print("Enter the Patient ID: ");
				int patientId = 0;
				try {
					patientId = scanner.nextInt();
				} catch (InputMismatchException e) {
					logger.error("Please enter integer values only.");
					System.err.println("Please enter digits only.");
					System.exit(0);
				}

				PatientBean searchPatient;
				try {
					searchPatient = patientService.getPatientDetails(patientId);
					System.out.println(searchPatient);

				} catch (TakeCareClinicException e) {
					logger.error("There's no data found in the dataBase with this Patient ID.");
					System.err.println(e.getMessage());
				}
				break;

			case 3:
				/**
				 * When user selects Case 3, Exit.
				 * 
				 * author @capgemini
				 */
				logger.info("You've exited from the operation successfully");

				System.out
						.println("You've exited from the operation successfully");
				System.exit(0);
				break;

			default:
				/**
				 * When user enters integer values, other than 1,2,3
				 * 
				 * author @capgemini
				 */
				logger.info("Invalid selection. Please try again.");

				System.out.println("Invalid selection. Please try again.");
				break;
			}

		}
	}
}