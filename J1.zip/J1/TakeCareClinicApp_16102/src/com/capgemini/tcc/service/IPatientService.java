package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareClinicException;

public interface IPatientService {
	int addPatientDetails(PatientBean patient) throws TakeCareClinicException;

	PatientBean getPatientDetails(int patientId) throws TakeCareClinicException;

	boolean validateDetails(PatientBean patient) throws TakeCareClinicException;
}
