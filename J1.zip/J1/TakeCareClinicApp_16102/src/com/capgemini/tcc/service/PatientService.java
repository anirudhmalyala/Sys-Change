package com.capgemini.tcc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exceptions.TakeCareClinicException;

public class PatientService implements IPatientService {
	IPatientDAO patientDao = new PatientDAO();

	@Override
	public int addPatientDetails(PatientBean patient)
			throws TakeCareClinicException {
		// TODO Auto-generated method stub
		return patientDao.addPatientDetails(patient);
	}

	@Override
	public PatientBean getPatientDetails(int patientId)
			throws TakeCareClinicException {
		// TODO Auto-generated method stub
		return patientDao.getPatientDetails(patientId);
	}

	@Override
	public boolean validateDetails(PatientBean patient)
			throws TakeCareClinicException {
		/**
		 * Validation for user entered patient details.
		 * 
		 * author@capgemini
		 */
		
		List<String> list = new ArrayList<>();
		boolean result = false;

		if (!validatePatientName(patient.getPatientName())) {
			list.add("Invalid Patient Name format! Name should start with Capital letter and the length should be inBetween 6 and 20.");
		}
		if (!validateAge(patient.getAge())) {
			list.add("Age ");
		}
		if (!validatePhoneNumber(patient.getPhoneNumber())) {
			list.add("Invalid Phone number! Length must be 10.");
		}

		if (!validateDescription(patient.getDescription())) {
			list.add("Invalid Description! The length should be 5 to 80.");
		}
		if (!list.isEmpty()) {
			result = false;
			throw new TakeCareClinicException(list + "");
		} else {
			result = true;
		}
		return result;
	}

	public boolean validatePatientName(String patientName) {
		String patientNameRegEx = "[A-Z]{1}[a-zA-Z]{5,20}";
		Pattern pattern = Pattern.compile(patientNameRegEx);
		Matcher matcher = pattern.matcher(patientName);
		return matcher.matches();
	}

	public boolean validateAge(int age) {
		String ageRegEx = "[0-9]{1,3}";
		Pattern pattern = Pattern.compile(ageRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(age));
		// String.valueOf() used to convert int type of age into String type
		return matcher.matches();
	}

	public boolean validatePhoneNumber(long phoneNumber) {
		String phoneNumberRegEx = "[1-9]{1}[0-9]{9}";
		Pattern pattern = Pattern.compile(phoneNumberRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(phoneNumber));
		// String.valueOf() used to convert long phoneNumber into String type
		return matcher.matches();
	}

	public boolean validateDescription(String description) {
		String descriptionRegEx = "[A-Za-z0-9]{5,80}";
		Pattern pattern = Pattern.compile(descriptionRegEx);
		Matcher matcher = pattern.matcher(description);
		return matcher.matches();
	}

}
