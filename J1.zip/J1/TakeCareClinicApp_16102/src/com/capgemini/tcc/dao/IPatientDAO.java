package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareClinicException;

public interface IPatientDAO {
	int addPatientDetails(PatientBean patient) throws TakeCareClinicException;

	PatientBean getPatientDetails(int patientId) throws TakeCareClinicException;
}
