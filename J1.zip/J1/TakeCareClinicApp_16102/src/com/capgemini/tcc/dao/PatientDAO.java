package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.TakeCareClinicException;
import com.capgemini.tcc.utility.JdbcUtility;

public class PatientDAO implements IPatientDAO {
	static Logger logger = Logger.getLogger(PatientDAO.class);

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;

	@Override
	public int addPatientDetails(PatientBean patient)
			throws TakeCareClinicException {
		/**
		 * addPatientDetails method used to insert the patient details
		 * 
		 * author@capgemini
		 */
		logger.info("Inserting the details into the database");

		int patientId = 0;
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QueryConstants.insertQuery);
			statement.setString(1, patient.getPatientName());
			statement.setInt(2, patient.getAge());
			statement.setLong(3, patient.getPhoneNumber());
			statement.setString(4, patient.getDescription());
			statement.executeUpdate();

			statement = connection.prepareStatement(QueryConstants.getIdQuery);
			resultSet = statement.executeQuery();
			resultSet.next();
			patientId = resultSet.getInt(1);

		} catch (SQLException e) {
			logger.error("The insertion is not performed in database.");

			throw new TakeCareClinicException(
					"The insertion is not performed in database.");
		}
		return patientId;
	}

	// ---------------------------------------------------------------------------------------------------------
	@Override
	public PatientBean getPatientDetails(int patientId)
			throws TakeCareClinicException {
		/**
		 * getPatientDetails takes integer patientId as arg and returns the
		 * search details based on patientId
		 * 
		 * author@capgemini
		 */
		logger.info("Getting details of patient using Patient ID");

		connection = JdbcUtility.getConnection();
		PatientBean patient = null;

		try {

			statement = connection
					.prepareStatement(QueryConstants.selectQuery);
			statement.setInt(1, patientId);

			resultSet = statement.executeQuery();
			resultSet.next();
			patient = new PatientBean();

			patient.setPatientId(resultSet.getInt(1));
			patient.setPatientName(resultSet.getString(2));
			patient.setAge(resultSet.getInt(3));
			patient.setPhoneNumber(resultSet.getLong(4));
			patient.setDescription(resultSet.getString(5));
			patient.setConsultationDate(resultSet.getDate(6));

			return patient;

		} catch (SQLException e) {
			logger.error("Sorry, there is no Patient with this ID");

			throw new TakeCareClinicException(
					"Sorry, there is no Patient with this ID");
		}
	}
}
