package com.capgemini.tcc.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exceptions.TakeCareClinicException;

public class PatientDAOTest {

	PatientDAO patientDao = null;

	@Before
	public void setUp() {
		patientDao = new PatientDAO();
	}

	@After
	public void tearDown() {
		patientDao = null;
	}

	@Test
	public void addPatientDetails() {

		PatientBean addPatient = new PatientBean();
		addPatient.setPatientName("Anirudh");
		addPatient.setAge(21);
		addPatient.setPhoneNumber(9099090990l);
		addPatient.setDescription("Eyecheckup");

		try {
			Integer patientId = patientDao.addPatientDetails(addPatient);
			assertNotNull(patientId);
			System.out
					.println("Successfully proved the Test Case for Adding the Patient Details.");

		} catch (TakeCareClinicException e) {
			System.err
					.println("Test Case failed for Adding the Patient Details");
		}

	}

	@Test
	public void getPatientDetails() {
		PatientBean searchPatient;

		try {
			searchPatient = patientDao.getPatientDetails(1001);
			assertEquals("Anirudh", searchPatient.getPatientName());
			System.out
					.println("Successfully proved the Test Case for Searching the Patient Details.");

		} catch (TakeCareClinicException e) {
			System.err
					.println("Test Case failed for Searching the Patient Details");
		}

	}
}
