package com.cg;

import org.apache.log4j.Logger;

public class Headache {

	public static void main(String[] args) {
		Logger log = Logger.getLogger(Headache.class.getName());
		log.info("koo");
	}

}
