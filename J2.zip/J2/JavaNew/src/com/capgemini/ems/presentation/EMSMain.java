package com.capgemini.ems.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.service.EmployeeService;
import com.capgemini.ems.service.EmployeeServiceImpl;

public class EMSMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmployeeService service=new EmployeeServiceImpl();
		
		System.out.println("EMployee Management System");
		System.out.println("1.Add Employee");
		System.out.println("2.Exit");
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Select your choice");
		int option= 0;
		try{
			option=scanner.nextInt();
		}catch(InputMismatchException e){
			System.out.println("Input Should contain only digits");
			System.exit(0);
		}
		
		
		switch(option){
		case 1:
			System.out.println("Enetr id");
			int id= scanner.nextInt();
			System.out.println("Enter name");
			String name= scanner.nextLine();
			System.out.println("Enter salary");
			double salary=scanner.nextDouble();
			
			Employee employee=new Employee(id,name,salary);
			break;
			
		case 2:
			
			System.out.println("Thank you, visit again");
			System.exit(0);
			break;
			
		default:
				System.out.println("Invalid Selection");
				break;
		}

	}

}
