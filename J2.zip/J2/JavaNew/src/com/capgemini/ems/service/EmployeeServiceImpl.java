package com.capgemini.ems.service;

public class EmployeeServiceImpl implements EmployeeService{

}
