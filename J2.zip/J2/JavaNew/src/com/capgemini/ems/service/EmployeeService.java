package com.capgemini.ems.service;

public interface EmployeeService {

}
