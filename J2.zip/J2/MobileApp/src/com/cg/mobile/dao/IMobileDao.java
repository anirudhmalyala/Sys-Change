package com.cg.mobile.dao;

import java.util.List;

import com.cg.mobile.MobileException.MobileException;
import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;

public interface IMobileDao {

	// int store(Customer customer) throws MobileException;

	public List<Mobile> getMobileByPrice(double Price);

	public List<Mobile> deleteOperation(int MobileId);

	public List<Mobile> getAllMobiles();

	public int storeDetails(Customer customer) throws MobileException;

}
