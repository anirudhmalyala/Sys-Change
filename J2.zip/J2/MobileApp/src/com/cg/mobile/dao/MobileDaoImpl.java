package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobile.MobileException.MobileException;
import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.utility.JdbcUtility;

public class MobileDaoImpl implements IMobileDao {

	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet resultSet = null;

	// --------------------------------------------------------------------------------------------------------
	@Override
	public List<Mobile> getMobileByPrice(double Price) {

		try {
			connection = JdbcUtility.getConnection();
			statement = connection.prepareStatement(QueryConstants.selectPrice);
			statement.setDouble(1, Price);
			resultSet = statement.executeQuery();
			Mobile m = null;
			List<Mobile> list = new ArrayList<>();
			while (resultSet.next()) {
				m = new Mobile();
				m.setMobileId(resultSet.getInt(1));
				m.setName(resultSet.getString(2));
				m.setPrice(resultSet.getDouble(3));
				m.setQuantity(resultSet.getString(4));
				list.add(m);
			}
			return list;
		} catch (Exception e) {

		}
		return null;
	}

	// --------------------------------------------------------------------------------------------------------
	@Override
	public List<Mobile> getAllMobiles() {
		// TODO Auto-generated method stub
		try {
			connection = JdbcUtility.getConnection();
			statement = connection.prepareStatement(QueryConstants.selectQuery);
			resultSet = statement.executeQuery();
			Mobile m = null;
			List<Mobile> list = new ArrayList<>();
			while (resultSet.next()) {
				m = new Mobile();
				m.setMobileId(resultSet.getInt(1));
				m.setName(resultSet.getString(2));
				m.setPrice(resultSet.getDouble(3));
				m.setQuantity(resultSet.getString(4));
				list.add(m);
			}
			return list;
		} catch (Exception e) {

		}
		return null;
	}

	// --------------------------------------------------------------------------------------------------------
	@Override
	public List<Mobile> deleteOperation(int MobileId) {
		// TODO Auto-generated method stub
		try {
			connection = JdbcUtility.getConnection();
			statement = connection.prepareStatement(QueryConstants.deleteQuery);
			statement.setInt(1, MobileId);
			statement.executeQuery();
			PreparedStatement statement1 = connection
					.prepareStatement(QueryConstants.selectQuery);
			// statement1.setInt(1, MobileId);
			resultSet = statement1.executeQuery();
			Mobile m1 = null;
			List<Mobile> list3 = new ArrayList<>();
			while (resultSet.next()) {
				m1 = new Mobile();
				m1.setMobileId(resultSet.getInt(1));
				m1.setName(resultSet.getString(2));
				m1.setPrice(resultSet.getDouble(3));
				m1.setQuantity(resultSet.getString(4));
				list3.add(m1);
			}
			return list3;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	// --------------------------------------------------------------------------------------------------------
	@Override
	public int storeDetails(Customer customer) throws MobileException {
		// TODO Auto-generated method stub
		int quantity = getQuantity(customer.getMobileId());
		connection = JdbcUtility.getConnection();

		int customerId = 0;

		if (customer.getQuantity() < quantity) {

			try {
				statement = connection
						.prepareStatement(QueryConstants.insertQuery);
				statement.setString(1, customer.getCustomerName());
				statement.setString(2, customer.getEmailId());
				statement.setLong(3, customer.getPhoneNumber());
				// statement.setString(1, customer.getPurchaseDate());
				statement.setInt(4, customer.getMobileId());
				statement.setInt(5, customer.getQuantity());

				statement.executeUpdate();

				customerId = getCustomerId();

				statement = connection
						.prepareStatement(QueryConstants.updateQuery);
				statement.setInt(1, customer.getQuantity());
				statement.setInt(2, customer.getMobileId());
				statement.executeUpdate();

			} catch (SQLException e) {
				throw new MobileException("statement not created");
				// e.printStackTrace();
			}
		}
		return customerId;
	}

	public int getQuantity(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		connection = JdbcUtility.getConnection();
		int quantity = 0;
		try {

			statement = connection
					.prepareStatement(QueryConstants.checkIdQuery);
			statement.setInt(1, mobileId);

			resultSet = statement.executeQuery();

			resultSet.next();

			quantity = resultSet.getInt(1);

		} catch (SQLException exception) {
			throw new MobileException("statement not cretaed..");
			// exception.printStackTrace();
		}
		return quantity;
	}

	public int getCustomerId() throws MobileException {
		// TODO Auto-generated method stub
		connection = JdbcUtility.getConnection();
		int customerId = 0;
		try {

			statement = connection
					.prepareStatement(QueryConstants.getCustomerId);

			resultSet = statement.executeQuery();

			resultSet.next();

			customerId = resultSet.getInt(1);

		} catch (SQLException exception) {
			throw new MobileException("statement not cretaed..");
			// exception.printStackTrace();
		}
		return customerId;
	}
}

// --------------------------------------------------------------------------------------------------------
