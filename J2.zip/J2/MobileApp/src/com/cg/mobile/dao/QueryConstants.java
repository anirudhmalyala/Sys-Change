package com.cg.mobile.dao;

public class QueryConstants {

	public static final String insertQuery = "insert into purchasedetails values(sequence.nextval,?,?,?,?,?)";
	public static final String checkIdQuery = "select quantity from mobiles where mobileid=?";
	public static final String getCustomerId = "select max(purchaseid) from purchasedetails";
	public static final String updateQuery = "update mobiles set quantity=quantity-? where mobileid=?";
	public static final String selectQuery = "SELECT *FROM mobiles";
	public static final String selectPrice = "SELECT *FROM mobiles WHERE price >=?";
	public static final String deleteQuery = "DELETE FROM mobiles WHERE mobileid =?";

}
