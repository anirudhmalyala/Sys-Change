package com.cg.mobile.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobile.MobileException.MobileException;
import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.dao.IMobileDao;
import com.cg.mobile.dao.MobileDaoImpl;

public class MobileServiceImpl implements IMobileService {

	IMobileDao dao = new MobileDaoImpl();
	List<String> list = new ArrayList<String>();

	// --------------------------------------------------------------------------------------------------------
	@Override
	public List<Mobile> getMobileByPrice(double Price) {
		// TODO Auto-generated method stub

		return (List<Mobile>) dao.getMobileByPrice(Price);
	}

	// --------------------------------------------------------------------------------------------------------
	@Override
	public List<Mobile> getAllMobiles() {
		// TODO Auto-generated method stub
		return (List<Mobile>) dao.getAllMobiles();
	}

	// --------------------------------------------------------------------------------------------------------
	@Override
	public boolean validateFileds(Customer customer) throws MobileException {

		boolean flag = false;

		if (!validateCustomerName(customer.getCustomerName())) {
			list.add("name length 6 to 20");
		}
		if (!validateEmailId(customer.getEmailId())) {
			list.add("email should be in correct format");
		}
		if (!validatePhoneNumber(customer.getPhoneNumber())) {
			list.add("phone numbe length should be 10");
		}
		if (!validateMobileId(customer.getMobileId())) {
			list.add("mobile should be 4 digits");
		}

		if (!list.isEmpty()) {
			flag = false;
			throw new MobileException(list + "");
		} else {
			flag = true;
		}
		return flag;

	}

	public boolean validateCustomerName(String customerName) {
		String customerNameRegEx = "[a-zA-Z]{6,20}";
		Pattern pattern = Pattern.compile(customerNameRegEx);
		Matcher matcher = pattern.matcher(customerName);
		return matcher.matches();
	}

	public boolean validateEmailId(String emailId) {
		String emailRegEx = "[a-zA-Z]{1}[a-zA-Z0-9]{1,}[@]{1}[a-zA-Z0-9]{1,}[.]{1}[a-zA-Z]{1,}";
		Pattern pattern = Pattern.compile(emailRegEx);
		Matcher matcher = pattern.matcher(emailId);
		return matcher.matches();
	}

	public boolean validatePhoneNumber(long phoneNumber) {
		String phoneNumberRegEx = "[1-9]{1}[0-9]{9}";
		Pattern pattern = Pattern.compile(phoneNumberRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(phoneNumber));
		return matcher.matches();
	}

	public boolean validateMobileId(int mobileId) {
		String mobileRegEx = "[1-9]{1}[0-9]{3}";
		Pattern pattern = Pattern.compile(mobileRegEx);
		Matcher matcher = pattern.matcher(String.valueOf(mobileId));
		return matcher.matches();
	}

	// --------------------------------------------------------------------------------------------------------
	@Override
	public List<Mobile> deleteOperation(int MobileId) {
		// TODO Auto-generated method stub
		return (List<Mobile>) dao.deleteOperation(MobileId);
	}

	// --------------------------------------------------------------------------------------------------------
	@Override
	public int storeDetails(Customer customer) throws MobileException {
		// TODO Auto-generated method stub
		return dao.storeDetails(customer);
	}
}
