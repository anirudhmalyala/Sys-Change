package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.MobileException.MobileException;
import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;

public interface IMobileService {

	public List<Mobile> getMobileByPrice(double Price);

	public List<Mobile> getAllMobiles();

	public boolean validateFileds(Customer customer) throws MobileException;

	public List<Mobile> deleteOperation(int MobileId);

	public int storeDetails(Customer customer) throws MobileException;

}
