package com.cg.mobile.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.mobile.MobileException.MobileException;
import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class Jaffa {

	public static void main(String[] args) {

		IMobileService service = new MobileServiceImpl();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("---------------------");
			System.out.println("1.	Insert");
			System.out.println("2.	Update");
			System.out.println("3.	View");
			System.out.println("4.	Delete");
			System.out.println("5.	Search");
			System.out.println("6.	Exit");
			System.out.println("Enter your option");
			int option = 0;
			try {
				option = sc.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("Enter only digits");
				System.exit(0);
			}

			switch (option) {
			case 1:
				// System.err.println("Still need to fill");
				sc.nextLine();
				System.out.println("Customer Name:");
				String customerName = sc.nextLine();
				System.out.println("Email Id:");
				String emailId = sc.nextLine();
				System.out.println("Phone Number:");
				long phoneNumber = 0;
				try {
					phoneNumber = sc.nextLong();
				} catch (InputMismatchException e) {
					// TODO: handle exception
					System.err.println("Enter only digits");
					// System.exit(0);
				}
				System.out.println("Mobile Id:");
				int mobileId = 0;
				try {
					mobileId = sc.nextInt();
				} catch (InputMismatchException e) {
					// TODO: handle exception
					System.err.println("Enter only digits");
					// System.exit(0);
				}
				System.out.println("Quantity");
				int quantity = 0;
				try {
					quantity = sc.nextInt();
				} catch (InputMismatchException e) {
					// TODO: handle exception
					System.err.println("Enter only digits");
				}
				Customer customer = new Customer(customerName, emailId,
						phoneNumber, mobileId, quantity);

				try {
					boolean result = service.validateFileds(customer);
					if (result) {
						int CustomerId;
						try {
							CustomerId = service.storeDetails(customer);
							System.out.println("id is: " + CustomerId);
						} catch (MobileException e) {
							// TODO: handle exception
							System.err.println(e.getMessage());
						}
					}

				} catch (MobileException e1) {
					System.err.println(e1.getMessage());
				}

				break;
			case 2:
				System.err.println("Still need to fill");
				break;
			case 3:
				List<Mobile> list3 = service.getAllMobiles();
				System.out.println("All available Mobiles are:");
				System.out.println("____________________________");
				for (Mobile m : list3) {

					System.out.println("\nID:" + m.getMobileId());
					System.out.println("Name:" + m.getName());
					System.out.println("Price:" + m.getPrice());
					System.out.println("Quantity:" + m.getQuantity());
				}
				break;
			case 4:
				System.out.print("Enter the mobileId which you have to delete");
				int MobileId = 0;
				try {
					MobileId = sc.nextInt();
				} catch (InputMismatchException e) {
					// TODO: handle exception
					System.err.println("Enter only digits");
					// System.exit(0);
				}
				List<Mobile> list4 = service.deleteOperation(MobileId);
				System.out.println("Mobiles for given cond are:");
				System.out.println("_______________________");
				for (Mobile m : list4) {
					System.out.println("\nID:" + m.getMobileId());
					System.out.println("Name:" + m.getName());
					System.out.println("Price:" + m.getPrice());
					System.out.println("Quantity:" + m.getQuantity());
				}

				break;
			case 5:
				System.out.print("Enter Price");
				double Price = sc.nextDouble();
				List<Mobile> list5 = service.getMobileByPrice(Price);
				System.out.println("Mobiles for given cond are:");
				System.out.println("____________________________");
				for (Mobile m : list5) {
					System.out.println("\nID:" + m.getMobileId());
					System.out.println("Name:" + m.getName());
					System.out.println("Price:" + m.getPrice());
					System.out.println("Quantity:" + m.getQuantity());
				}
				break;
			case 6:
				System.out.println("You have selected Exit.");
				System.exit(0);
				break;
			default:
				System.out
						.println("Invalid selection, please select in the given range only.");
				break;
			}
		}
	}
}
