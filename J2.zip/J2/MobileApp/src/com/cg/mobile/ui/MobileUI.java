package com.cg.mobile.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;
import com.cg.mobile.MobileException.MobileException;

public class MobileUI {

	public static void main(String[] args) {

		IMobileService service = new MobileServiceImpl();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("---------------------");
			System.out.println("1.	Insert");
			System.out.println("2.	Update");
			System.out.println("3.	View");
			System.out.println("4.	Delete");
			System.out.println("5.	Search");
			System.out.println("6.	Exit");
			System.out.println("Enter your option");
			int option =0;
			try {
				option = sc.nextInt();
			} catch (Exception e) {
				System.err.println("Enter only digits");
				System.exit(0);
			}

			switch (option) {
			case 1:
				System.err.println("Still need to fill");
			/*	sc.nextLine();
				System.out.println("Customer Name:");
				String customername = sc.nextLine();
				System.out.println("Email Id:");
				String emailid = sc.nextLine();
				System.out.println("Phone Number:");
				long phonenumber = 0;
				try {
					phonenumber = sc.nextLong();
				} catch (Exception e) {
					// TODO: handle exception
					System.err.println("Enter only digits");
					// System.exit(0);
				}
				System.out.println("Mobile Id:");
				int mobileid = 0;
				try {
					mobileid = sc.nextInt();
				} catch (Exception e) {
					// TODO: handle exception
					System.err.println("Enter only digits");
					// System.exit(0);
				}
				Customer customer = new Customer(customername, emailid,
						phonenumber, mobileid);

				try {
					boolean resut = service.validateFileds(customer);
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/

				break;
			case 2:
				System.err.println("Still need to fill");
				break;
			case 3:
				List<Mobile> list3 = service.getAllMobiles();
				System.out.println("All available Mobiles are:");
				System.out.println("____________________________");
				for (Mobile m : list3) {

					System.out.println("\nID:" + m.getMobileId());
					System.out.println("Name:" + m.getName());
					System.out.println("Price:" + m.getPrice());
					System.out.println("Quantity:" + m.getQuantity());
				}
				break;
			case 4:
				System.out.print("Enter the mobileId which you have to delete");
				int MobileId = 0;
				try {
					MobileId = sc.nextInt();
				} catch (InputMismatchException e) {
					// TODO: handle exception
					System.err.println("Enter only digits");
					// System.exit(0);
				}
				List<Mobile> list4 = service.deleteOperation(MobileId);
				System.out.println("Mobiles for given cond are:");
				System.out.println("____________________________");
				for (Mobile m : list4) {
					System.out.println("\nID:" + m.getMobileId());
					System.out.println("Name:" + m.getName());
					System.out.println("Price:" + m.getPrice());
					System.out.println("Quantity:" + m.getQuantity());
				}				

				break;
			case 5:
				System.out.print("Enter Price");
				double Price = sc.nextDouble();
				List<Mobile> list5 = service.getMobileByPrice(Price);
				System.out.println("Mobiles for given cond are:");
				System.out.println("____________________________");
				for (Mobile m : list5) {
					System.out.println("\nID:" + m.getMobileId());
					System.out.println("Name:" + m.getName());
					System.out.println("Price:" + m.getPrice());
					System.out.println("Quantity:" + m.getQuantity());
				}
				break;
			case 6:
				System.out.println("You have selected Exit.");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid selection, please select in the given range only.");
				break;
			}
		}
	}
}
