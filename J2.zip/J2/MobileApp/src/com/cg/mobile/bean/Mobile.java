package com.cg.mobile.bean;

public class Mobile {
	private int MobileId;
	private String Name;
	private double Price;
	private String Quantity;

	public Mobile() {
		// TODO Auto-generated constructor stub
	}

	public Mobile(int mobileId, String name, double price, String quantity) {
		super();
		MobileId = mobileId;
		Name = name;
		Price = price;
		Quantity = quantity;
	}

	public int getMobileId() {
		return MobileId;
	}

	public void setMobileId(int mobileId) {
		MobileId = mobileId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public double getPrice() {
		return Price;
	}

	public void setPrice(double price) {
		Price = price;
	}

	public String getQuantity() {
		return Quantity;
	}

	public void setQuantity(String quantity) {
		Quantity = quantity;
	}



}
