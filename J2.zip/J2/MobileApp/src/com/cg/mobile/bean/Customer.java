package com.cg.mobile.bean;

import java.util.Date;

public class Customer {
	private String CustomerName;
	private String EmailId;
	private long PhoneNumber;
	private Date PurchaseDate;
	private int MobileId;
	private int Quantity;

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(String customerName, String emailId, long phoneNumber,
			int mobileId) {
		super();
		CustomerName = customerName;
		EmailId = emailId;
		PhoneNumber = phoneNumber;
		MobileId = mobileId;
	}

	public Customer(String customerName, String emailId, long phoneNumber,
			int mobileId, int quantity) {
		super();
		CustomerName = customerName;
		EmailId = emailId;
		PhoneNumber = phoneNumber;
		MobileId = mobileId;
		Quantity = quantity;
	}

	public Customer(String customerName, String emailId, long phoneNumber,
			Date purchaseDate, int mobileId, int quantity) {
		super();
		CustomerName = customerName;
		EmailId = emailId;
		PhoneNumber = phoneNumber;
		PurchaseDate = purchaseDate;
		MobileId = mobileId;
		Quantity = quantity;
	}

	public String getCustomerName() {
		return CustomerName;
	}

	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public long getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public Date getPurchaseDate() {
		return PurchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		PurchaseDate = purchaseDate;
	}

	public int getMobileId() {
		return MobileId;
	}

	public void setMobileId(int mobileId) {
		MobileId = mobileId;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
}