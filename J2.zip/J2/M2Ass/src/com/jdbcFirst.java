package com;

import java.sql.*;

public class jdbcFirst {
	
	public static void main(String a[]) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			Connection conn = DriverManager.getConnection(url, "system","Capgemini123"); 
			
			System.out.println("connected");
			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT empno,ename FROM emp");
			
			while (rs.next()) {
				System.out.println("Emo No = " + rs.getInt("empno"));
				System.out.println("Emo Name = " + rs.getString("ename"));
				//System.out.println("Job Role = " + rs.getString("job"));
			}
		} catch (Exception e) {

		}
	}

}
