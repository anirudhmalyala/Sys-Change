package com.capgemini.emp.ui;
import com.capgemini.emp.bean.*;
import java.util.*;

public class Client {
	byte option;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Employee E=new Employee();
		
		System.out.println("Available Options");
		System.out.println("1.Enter Employee Details\n2. Exit");
		
		byte option = sc.nextByte();
		
		if(option==1){
			System.out.println("1.Enter Employee Details");
			E.setEmployeeD();
			E.setEmployeeD2();			
			E.getEmployeeD();
			
		}
		else if(option==2)
			System.out.println("2.Exit");
		else System.out.println("Wrong Choice! Try Again");

	}

}
