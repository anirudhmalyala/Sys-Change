package com.capgemini.emp.dao;
import com.capgemini.emp.bean.*;
import com.capgemini.emp.ui.*;

public class EmployeeDao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		if(Employee.ERole.equals("SeniorManager"))
		{
			Employee.TA=0.25*(Employee.Salary);
		}
		else if(Employee.ERole.equals("Manager"))
		{
			Employee.TA=0.20*(Employee.Salary);
		}
		else if(Employee.ERole.equals("SeniorConsultant"))
		{
			Employee.TA=0.15*(Employee.Salary);
		}
		else if(Employee.ERole.equals("Consultant"))
		{
			Employee.TA=0.10*(Employee.Salary);
		}
		else
		{
			System.out.println("Inavlid entry!");	
		}
		System.out.println("Travel allowance is:"+Employee.TA);
		}
}
