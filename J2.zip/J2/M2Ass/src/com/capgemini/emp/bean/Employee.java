package com.capgemini.emp.bean;

import com.capgemini.emp.ui.*;

import java.util.regex.*;
import java.util.*; 


public class Employee {
	private static int ID;
	private static String Name;
	private static String Number;
	public static String ERole;
	public static double Salary;
	private static String Email;
	public static double TA;
	public static boolean bNumber;
	public static boolean bEmail;
	
	
	public static void setEmployeeD() 
    { 
    	Scanner sc = new Scanner(System.in); 
   	
    	System.out.println("Enter the name of the Employee: ");
        Name = sc.nextLine();     

        

        System.out.println("Enter the Employee Role: ");
        ERole = sc.next(); 

        System.out.println("Enter the Salary: ");
        Salary = sc.nextDouble(); 

        
    }
	
	public static void setEmployeeD2() 
    { 
    	Scanner scan = new Scanner(System.in);
    	do{
    	System.out.println("Enter Employee phone number: ");
        Number = scan.nextLine();
        boolean bNumber=Pattern.matches("[6-9][0-9]{9}", Number);
        
        System.out.println("Enter the Email ID: ");
        Email = scan.next();
        boolean bEmail=Pattern.matches("[A-Za-z][A-Za-z0-9][@][A-Za-z0-9][.][A-Za-z]", Email);
    	}while(bNumber==false && bEmail==false);
    }
	
	public static void getEmployeeD()    { 
        Random random=new Random();
        ID=random.nextInt(10000);
        
        System.out.println("Employee has been successfully Register along with the "+ID);
        System.out.println("Name of the Employee: "+Name);
        
      if(bNumber==true)
        	System.out.println("Employee Phone Number: "+Number);
        else setEmployeeD2();
       //	System.out.println("Invalid Number");
        
        System.out.println("Employee Role: "+ERole);
        System.out.println("Salary: "+Salary);
        
        //if(bEmail=true)
        	System.out.println("Email ID: "+Email);
      //  else
        	//System.out.println("Invalid Email");

}
}
